Z80 TV Game: 3D Printed Cartridge Shells v2.0
28.05.2026 - Alex J. Lowry

  Top v2 (No Text).stl - Top (or front) half of cartridge shell with plain front
                           face. This version is easier to print.

Top v2 (With Text).stl - Top (or front) half of cartridge shell with embossed
                           "Z80 TV GAME" logo and label guide. This version may
                           be more difficult to print, even when using a
                           professional printing service.

Top v2 (Multicart).stl - Same as the "No Text" top half, but with a cutout for
                           the DIP switches on the 32KB x 16 multi-cartridge.

         Bottom v2.stl - The bottom half of the cartridge shell.
