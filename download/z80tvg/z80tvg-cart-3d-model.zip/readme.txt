Z80 TV Game: 3D Printed Cartridge Shells v1.0
17.04.2026 - Alex J. Lowry

  Top (No Text).stl - Top (or front) half of cartridge shell with plain front
                        face. This version is easier to print.

Top (With Text).stl - Top (or front) half of cartridge shell with embossed
                        "Z80 TV GAME" logo and label guide. This version may
                        be more difficult to print, even when using a
                        professional printing service.

Top (Multicart).stl - Same as the "No Text" top half, but with a cutout for
                      the DIP switches on the 32KB x 16 multi-cartridge.

         Bottom.stl - The bottom half of the cartridge shell.
