extern word Score;
extern word HiScore;
extern byte RemainCount;
extern byte TimeRate;
extern byte CurrentStage;
extern word StageTime;
extern bool StageClear;

extern void AddScore(word pts);
extern void DrawAll();