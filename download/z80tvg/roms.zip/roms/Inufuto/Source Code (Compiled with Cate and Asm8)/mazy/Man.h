extern byte ManX, ManY;
extern bool ManLost;

extern void InitMan();
extern void DrawMan();
extern void MoveMan();
extern void EndMan();
