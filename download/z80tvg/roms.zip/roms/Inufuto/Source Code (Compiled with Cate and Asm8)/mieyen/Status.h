extern void PrintStatus();
extern void PrintScore();
extern void PrintFoodCount();
extern void PrintGameOver();
extern void Title();
