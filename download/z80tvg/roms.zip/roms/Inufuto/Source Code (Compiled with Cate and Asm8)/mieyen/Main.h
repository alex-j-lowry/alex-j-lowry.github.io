extern word Score;
extern word HiScore;
extern byte RemainCount;
extern byte CurrentStage;
extern byte FoodCount;

extern void AddScore(word pts);

extern void Wait(byte t);
