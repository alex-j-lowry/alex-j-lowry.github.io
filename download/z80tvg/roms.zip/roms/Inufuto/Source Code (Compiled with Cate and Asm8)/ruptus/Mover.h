extern bool HitMover(byte x1, byte y1, byte size1, byte x2, byte y2, byte size2);
