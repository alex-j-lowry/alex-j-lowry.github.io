extern word Score;
extern word HiScore;
extern byte RemainFighterCount;
extern byte Clock;

extern void AddScore(word pts);
extern void DrawAll();
extern void Wait(byte t);
