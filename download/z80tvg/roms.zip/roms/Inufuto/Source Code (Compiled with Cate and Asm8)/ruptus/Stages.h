constexpr byte StageCount = 10;
constexpr byte MaxFortCount = 7;
constexpr byte MaxBarrierCount = 8;
