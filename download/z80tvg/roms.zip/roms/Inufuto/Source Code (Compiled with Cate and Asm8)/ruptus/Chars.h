
constexpr byte Char_Space = 0x0;
constexpr byte Char_Ascii = 0x0;
constexpr byte Char_Logo = 0x40;
constexpr byte Char_FighterBullet = 0x50;
constexpr byte Char_EnemyBullet = 0x54;
constexpr byte Char_BarrierHead = 0x55;
constexpr byte Char_Barrier = 0x56;
constexpr byte Char_Star = 0x58;
constexpr byte Char_Fighter = 0x59;
constexpr byte Char_Enemy = 0x79;
constexpr byte Char_SmallBang = 0x99;
constexpr byte Char_LargeBang = 0x9D;
constexpr byte Char_Item = 0xAD;
constexpr byte Char_Fort = 0xB1;
constexpr byte Char_End = 0xD5;
