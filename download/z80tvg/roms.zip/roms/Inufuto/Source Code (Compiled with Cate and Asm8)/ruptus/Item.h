extern byte PowerX, PowerY;

extern void InitItem();
extern void StartItem(byte x, byte y);
extern void DrawItem();
extern bool HitItem(byte x, byte y, byte size);
