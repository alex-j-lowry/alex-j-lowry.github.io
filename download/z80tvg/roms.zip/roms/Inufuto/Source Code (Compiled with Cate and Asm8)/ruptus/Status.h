extern void PrintStatus();
extern void PrintScore();
extern void PrintRemain();
extern void PrintGameOver();
extern void Title();
