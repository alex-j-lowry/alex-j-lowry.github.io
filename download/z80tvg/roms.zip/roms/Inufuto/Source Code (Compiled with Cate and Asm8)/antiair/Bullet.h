extern void InitBullets();
extern bool CanFire();
extern void StartBullet();
extern void MoveBullets();
