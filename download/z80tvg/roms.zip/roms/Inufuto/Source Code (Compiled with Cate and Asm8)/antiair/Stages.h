#include "Stage.h"

constexpr byte StageCount = 10;

extern const Stage[] Stages;
