extern void WaitVSyncIn();
extern void WaitVSyncOut();