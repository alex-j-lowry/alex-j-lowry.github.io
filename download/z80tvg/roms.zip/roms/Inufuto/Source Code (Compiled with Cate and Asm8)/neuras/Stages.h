extern const Stage[] Stages;
constexpr byte StageCount = 10;
