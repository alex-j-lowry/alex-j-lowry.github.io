#include "Bullet.h"

extern Bullet[] MyBullets;

extern void InitMyBullets();
extern void StartMyBullet(bool on);
extern void MoveMyBullets();
// extern bool HitMyBullet(ptr<Movable> pMovable, byte x, byte y);
