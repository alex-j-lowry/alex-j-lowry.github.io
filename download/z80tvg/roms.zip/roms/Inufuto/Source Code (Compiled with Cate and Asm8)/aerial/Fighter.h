#include "Movable.h"

// struct Fighter {
//     Movable _;
// };


extern void ShowFighter(ptr<Movable> pFighter, byte pattern);