#include "Fighter.h"

extern Movable MyFighter;
extern sbyte MyFighterDy;

extern void InitMyFighter();
extern void MoveMyFighter();
extern bool HitBulletMyFighter(byte x, byte y);
extern bool HitMovableMyFighter(byte x, byte y);
