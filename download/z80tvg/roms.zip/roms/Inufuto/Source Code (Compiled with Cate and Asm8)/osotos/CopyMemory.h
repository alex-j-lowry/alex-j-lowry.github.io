// extern void CopyMemory(ptr<byte> pDestination, ptr<byte> pSource, word length);
extern void FillMemory(ptr<byte> pDestination, word length, byte b);
