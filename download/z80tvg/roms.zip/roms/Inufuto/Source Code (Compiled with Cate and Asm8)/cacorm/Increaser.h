extern Movable Increaser;

extern void InitIncreaser();
extern void ShowIncreaser(byte x, byte y);
extern void HideIncreaser();
extern bool IsIncreaserVisible();
