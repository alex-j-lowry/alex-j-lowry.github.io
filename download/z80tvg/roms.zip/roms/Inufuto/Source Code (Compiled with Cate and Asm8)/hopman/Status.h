extern void PrintStatus();
extern void PrintScore();
extern void PrintTime();
extern void PrintGameOver();
extern void PrintTimeUp();
extern void PrintPerfect();
extern void Title();
