extern void PrintStatus();
extern void PrintScore();
extern void PrintTime();
extern void PrintHeldKnives();
extern void PrintGameOver();
extern void PrintTimeUp();
extern void Title();
