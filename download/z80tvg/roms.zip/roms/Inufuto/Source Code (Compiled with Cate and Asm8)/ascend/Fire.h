constexpr byte Item_1Up = 0x40;
constexpr byte Item_Power = 0x20;

extern Actor[] Fires;

extern void InitFires();
extern void StartFire();
extern void MoveFires();