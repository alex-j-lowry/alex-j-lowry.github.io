extern Actor[] Monsters;

extern void InitMonsters();
extern void MoveMonsters();
