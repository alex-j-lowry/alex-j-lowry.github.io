
constexpr byte StageCount = 10;
