
constexpr byte Char_Space = 0x0;
constexpr byte Char_Ascii = 0x0;
constexpr byte Char_Logo = 0x40;
constexpr byte Char_FighterBullet = 0x50;
constexpr byte Char_EnemyBullet = 0x51;
constexpr byte Char_Barrier = 0x52;
constexpr byte Char_BarrierHead = 0x53;
constexpr byte Char_Fighter = 0x54;
constexpr byte Char_SkyEnemy = 0x58;
constexpr byte Char_GroundEnemy = 0x80;
constexpr byte Char_Bang = 0x88;
constexpr byte Char_Item = 0x9C;
constexpr byte Char_Fort = 0xA0;
constexpr byte Char_Terrain = 0xC4;
constexpr byte Char_End = 0xCE;
