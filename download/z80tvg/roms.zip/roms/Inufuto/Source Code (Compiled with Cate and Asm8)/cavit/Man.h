#include "Movable.h"

extern Movable man;

extern void StartMan();
extern void MoveMan();
extern void LooseMan();
