constexpr byte StageCount = 10;
constexpr byte MaxBoxCount = 5;
constexpr byte MaxRockCount = 4;
constexpr byte MaxChaserCount = 4;
constexpr byte MaxGhostCount = 2;
extern const ptr<byte>[] Stages;
