#include "Movable.h"

extern void InitPoints();
extern void StartPoint(byte x, byte y, byte rate);
extern void UpdatePoints();
extern void DrawPoints();
