#include "Stage.h"

constexpr byte StageCount = 8;
constexpr byte MaxMonsterCount = 4;

extern const Stage[] Stages;
