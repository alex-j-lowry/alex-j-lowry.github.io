extern word Score;
extern word HiScore;
extern byte RemainCount;
extern byte CurrentStage;
extern byte StageTime;
extern byte Clock;

extern void DrawAll();
extern void AddScore(word pts);