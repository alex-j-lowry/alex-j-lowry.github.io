
constexpr byte Char_Space = 0x0;
constexpr byte Char_Ascii = 0x0;
constexpr byte Char_Logo = 0x40;
constexpr byte Char_Fence = 0x50;
constexpr byte Char_Wall = 0x52;
constexpr byte Char_HardWall = 0x56;
constexpr byte Char_Meter = 0x57;
constexpr byte Char_Bullet = 0x59;
constexpr byte Char_MyRobo = 0x5B;
constexpr byte Char_EnemyRobo = 0x7B;
constexpr byte Char_SmallBang = 0x9B;
constexpr byte Char_LargeBang = 0x9F;
constexpr byte Char_MyFort = 0xAF;
constexpr byte Char_EnemyFort = 0xBB;
constexpr byte Char_End = 0xC7;
