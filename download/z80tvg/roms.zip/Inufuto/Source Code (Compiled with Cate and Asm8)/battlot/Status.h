// extern ptr<byte> PrintS(ptr<byte> address, ptr<byte> p);
// extern void Print2x2(ptr<byte> address, byte pattern);
extern void PrintStatus();
extern void PrintScore();
extern void PrintTime();
extern void PrintGameOver();
extern void PrintTimeUp();
extern void Title();
extern void DrawFence();