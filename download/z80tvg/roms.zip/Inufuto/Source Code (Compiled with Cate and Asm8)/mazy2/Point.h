#include "Movable.h"

extern byte PointRate;

extern void InitPoints();
extern void StartPoint(byte x, byte y);
extern void UpdatePoints();
extern void DrawPoints();
