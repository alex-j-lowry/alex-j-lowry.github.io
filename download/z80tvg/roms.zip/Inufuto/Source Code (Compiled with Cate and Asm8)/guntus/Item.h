extern byte PowerX, PowerY;

extern void InitItem();
extern void StartItem(byte x, byte y);
extern void MoveItem();
