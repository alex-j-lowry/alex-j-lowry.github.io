extern void CallSound();
extern void Sound_Loose();
extern void Sound_Item();
extern void Sound_Beep();
extern void Sound_Start();
extern void Sound_Clear();
extern void Sound_GameOver();
