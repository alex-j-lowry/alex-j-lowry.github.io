constexpr byte StageCount = 16;
extern const ptr<byte>[] Stages;
