#include "Movable.h"

extern Movable[] Points;

extern void InitPoints();
extern void StartPoint(byte x, byte y, byte rate);
extern void UpdatePoints();
