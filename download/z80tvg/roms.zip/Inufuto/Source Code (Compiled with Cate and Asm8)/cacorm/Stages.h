constexpr byte StageCount = 10;
constexpr byte MaxItemCount = 8;
constexpr byte MaxMonsterCount = 4;
extern const Stage[] Stages;
