extern void PrintStatus();
extern void PrintScore();
extern void PrintTime();
extern void PrintGameOver();
extern void PrintTimeUp();
extern void Title();
extern void DrawFence();
