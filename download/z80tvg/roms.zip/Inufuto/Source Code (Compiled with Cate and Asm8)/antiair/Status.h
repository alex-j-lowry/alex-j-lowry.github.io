extern word Score;
extern word HiScore;
extern byte RemainCount;
extern byte CurrentStage;

extern void PrintStatus();
extern void PrintScore();
extern void PrintStage();
extern void PrintRemain();
extern void PrintGameOver();
extern void Title();
extern void AddScore(word pts);
extern void DrawGround();
