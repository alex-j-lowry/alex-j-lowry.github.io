extern void CallSound();
extern void Sound_Fire();
extern void Sound_Hit();
extern void Sound_Loose();
extern void Sound_Start();
extern void Sound_GameOver();
