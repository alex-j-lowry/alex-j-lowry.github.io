constexpr byte StageCount = 10;
constexpr byte MaxItemCount = 8;
constexpr byte MaxMonsterCount = 2;
constexpr byte MaxLiftCount = 6;
