extern byte FortY;
extern byte FortLife;
// extern byte FortCharOffset;


extern void InitFort();
extern void StartFort();

// extern void SetFortPattern();
extern void DrawFort();
extern void EraseFort();
extern void MoveFort();
extern bool HitFort(byte x, byte y);
