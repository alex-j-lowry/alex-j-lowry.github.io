#include "Stage.h"

constexpr byte StageCount = 8;
constexpr byte MaxItemCount = 21;
constexpr byte MaxMonsterCount = 5;
constexpr byte MaxLiftCount = 3;

extern const Stage[] Stages;
