#include "Stage.h"

constexpr byte StageCount = 10;
constexpr byte MaxItemCount = 24;
constexpr byte MaxMonsterCount = 4;

extern const Stage[] Stages;
