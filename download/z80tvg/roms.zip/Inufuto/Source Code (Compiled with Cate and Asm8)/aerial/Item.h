#include "Movable.h"

extern Movable Item;

extern void InitItem();
extern void StartItem(byte x, byte y);
extern void MoveItem();
