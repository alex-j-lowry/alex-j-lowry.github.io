extern ptr<byte> PrintByteNumber3(ptr<byte> address, byte b);
extern ptr<byte> PrintByteNumber2(ptr<byte> address, byte b);
extern ptr<byte> PrintNumber5(ptr<byte> address, word w);
extern ptr<byte> PrintNumber3(ptr<byte> address, word w);
