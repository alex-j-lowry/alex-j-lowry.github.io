#include "Bullet.h"

extern Bullet[] EnemyBullets;

extern void InitEnemyBullets();
extern ptr<Bullet> StartEnemyBullet(byte x, byte y);
extern void MoveEnemyBullets();
