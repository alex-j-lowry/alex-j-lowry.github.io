extern word Score;
extern word HiScore;
extern byte RemainCount;
extern byte CurrentStage;

extern void AddScore(word pts);
