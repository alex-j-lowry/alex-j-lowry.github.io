
@echo off

echo.
echo              ***  XBM to Z80 TV Game assembly converter  ***
echo              ***   15.02.2026 - alex-j-lowry.github.io   ***
echo.
echo  To convert an XBM image to a Z80TVG assembly listing, provide the image's
echo   filename without its extention as an argument. For example, "xbm2asm image"
echo   will generate the file "image.asm" from the data in "image.xbm".
echo.
echo  The input file should not be larger than 168x210 pixels. The Z80TVG outputs
echo   wide pixels, so you should expect images to be stretched horizontally by
echo   approximately 1.5x.
echo.
echo  You'll need to install the GnuWin32 packages Grep and Sed for this script to
echo    work properly. Make sure to add the install directory to your PATH variable.
echo    https://gnuwin32.sourceforge.net/packages.html
echo.

if [%1]==[] goto noargument
if not exist "%1.xbm" goto nofile

echo  Removing extra text...
grep "0x" %1.xbm > tempxbm1.txt
sed s/,[[:space:]]/\n/g tempxbm1.txt > tempxbm2.txt
grep -v -e "^[[:space:]]*$" tempxbm2.txt > tempxbm1.txt
sed -r "s/^0x//" tempxbm1.txt > tempxbm2.txt

echo  Inverting nybbles (pass 1)...
sed s/0/g/g tempxbm2.txt > tempxbm1.txt
sed s/1/h/g tempxbm1.txt > tempxbm2.txt
sed s/2/i/g tempxbm2.txt > tempxbm1.txt
sed s/3/j/g tempxbm1.txt > tempxbm2.txt
sed s/4/k/g tempxbm2.txt > tempxbm1.txt
sed s/5/l/g tempxbm1.txt > tempxbm2.txt
sed s/6/m/g tempxbm2.txt > tempxbm1.txt
sed s/7/n/g tempxbm1.txt > tempxbm2.txt
sed s/8/o/g tempxbm2.txt > tempxbm1.txt
sed s/9/p/g tempxbm1.txt > tempxbm2.txt
sed s/a/q/g tempxbm2.txt > tempxbm1.txt
sed s/b/r/g tempxbm1.txt > tempxbm2.txt
sed s/c/s/g tempxbm2.txt > tempxbm1.txt
sed s/d/t/g tempxbm1.txt > tempxbm2.txt
sed s/e/u/g tempxbm2.txt > tempxbm1.txt
sed s/f/v/g tempxbm1.txt > tempxbm2.txt

rem              *** Character replacement order: ***
rem --------------------------------------------------------------
rem ORIGNL.EQVLNT.INVERT ORIGNL.EQVLNT.INVERT ORIGNL.EQVLNT.INVERT
rem --------------------------------------------------------------
rem  0    . g    . f      1    . h    . e      2    . i    . d
rem  0000 . 1111 . 1111   0001 . 1110 . 1110   0010 . 1101 . 1101
rem --------------------------------------------------------------
rem  3    . j    . c      4    . k    . b      5    . l    . a
rem  0011 . 1100 . 1100   0100 . 1011 . 1011   0101 . 1010 . 1010
rem --------------------------------------------------------------
rem  6    . m    . 9      7    . n    . 8      8    . o    . 7
rem  0110 . 1001 . 1001   0111 . 1000 . 1000   1000 . 0111 . 0111
rem --------------------------------------------------------------
rem  9    . p    . 6      a    . q    . 5      b    . r    . 4
rem  1001 . 0110 . 0110   1010 . 0101 . 0101   1011 . 0100 . 0100
rem --------------------------------------------------------------
rem  c    . s    . 3      d    . t    . 2      e    . u    . 1
rem  1100 . 0011 . 0011   1101 . 0010 . 0010   1110 . 0001 . 0001
rem --------------------------------------------------------------
rem  f    . v    . 0
rem  1111 . 0000 . 0000
rem --------------------------------------------------------------

echo  Inverting nybbles (pass 2)...
sed s/g/f/g tempxbm2.txt > tempxbm1.txt
sed s/h/e/g tempxbm1.txt > tempxbm2.txt
sed s/i/d/g tempxbm2.txt > tempxbm1.txt
sed s/j/c/g tempxbm1.txt > tempxbm2.txt
sed s/k/b/g tempxbm2.txt > tempxbm1.txt
sed s/l/a/g tempxbm1.txt > tempxbm2.txt
sed s/m/9/g tempxbm2.txt > tempxbm1.txt
sed s/n/8/g tempxbm1.txt > tempxbm2.txt
sed s/o/7/g tempxbm2.txt > tempxbm1.txt
sed s/p/6/g tempxbm1.txt > tempxbm2.txt
sed s/q/5/g tempxbm2.txt > tempxbm1.txt
sed s/r/4/g tempxbm1.txt > tempxbm2.txt
sed s/s/3/g tempxbm2.txt > tempxbm1.txt
sed s/t/2/g tempxbm1.txt > tempxbm2.txt
sed s/u/1/g tempxbm2.txt > tempxbm1.txt
sed s/v/0/g tempxbm1.txt > tempxbm2.txt

echo  Adding "db $" statements...
sed -r "s/^/ db $/" tempxbm2.txt > tempxbm1.txt

rem The statement "db $" has now been added to blank lines as well, which will
rem   confuse the assembler. The following command will remove these lines.
grep -v -e "^ db \$$" tempxbm1.txt > tempxbm2.txt

rem Convert Unix line breaks to DOS line breaks for better Windows/DOS compatibility:
sed -r "s/\n/\r\n/" tempxbm2.txt > %1.asm

echo  Deleting temporary files...
del tempxbm1.txt
del tempxbm2.txt

echo.
echo  Finished!

exit /B 1

:noargument

echo  No file specified!

exit /B 1

:nofile

echo  Input file does not exist!

exit /B 1
