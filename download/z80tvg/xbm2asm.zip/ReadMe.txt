         ***  XBM to Z80 TV Game assembly code converter V2.0  ***
         ***    05.05.2026 - https://alex-j-lowry.github.io    ***

To convert an X BitMap (XBM) monochrome image to a Z80 TV Game assembly
listing that can be included in your programs, run xbm2asm.bat from a command
window and provide the image's filename without its extension as an argument.
For example:
   xbm2asm image
will generate the listing "image.asm" from the data in "image.xbm".

The input file should not be larger than 168x210 pixels. The Z80TVG outputs
wide pixels, so you should expect images to be stretched horizontally by
approximately 1.5x.

The XBM format is supported by many free image viewers and editors, including
GIMP.

You'll need to install the GnuWin32 packages Grep and Sed for this script to
work properly. Make sure to add the install directory to your PATH variable.
   https://gnuwin32.sourceforge.net/packages.html
 
The GnuWin32 install directory is usually:
   C:\Program Files\GnuWin32\bin          ...on 32-bit machines, or
   C:\Program Files (x86)\GnuWin32\bin    ...on 64-bit machines.

This script and the GnuWin32 packages should work with any version of Windows
from Windows 2000 onwards.
