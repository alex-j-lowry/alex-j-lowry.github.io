Attention: As of 29.12.2025, these circuits have not yet been tested!

Achtung: Stand 29.12.2025 sind diese Schaltungen noch nicht getestet worden!